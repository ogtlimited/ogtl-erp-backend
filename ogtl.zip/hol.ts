// const holidays = [
//     {
//         1 Jan	Friday	New Year's Day	Public Holiday
// 14 Feb	Sunday	Valentine's Day	Observance
// 17 Feb	Wednesday	Ash Wednesday	Observance, Christian
// 8 Mar	Monday	Women's Day	Observance
// 14 Mar	Sunday	Mothering Sunday	Observance
// 20 Mar	Saturday	March Equinox	Season
// 2 Apr	Friday	Good Friday	Public Holiday
// 3 Apr	Saturday	Holy Saturday	Observance, Christian
// 4 Apr	Sunday	Easter Sunday	Observance, Christian
// 5 Apr	Monday	Easter Monday	Public Holiday
// 1 May	Saturday	Workers' Day	Public Holiday
// 3 May	Monday	Day off for Workers' Day	Public Holiday
// 12 May	Wednesday	Id el Fitr holiday	Public Holiday
// 13 May	Thursday	Id el Fitr	Public Holiday
// 27 May	Thursday	Children's Day	Observance
// 12 Jun	Saturday	Democracy Day	Public Holiday
// 14 Jun	Monday	Day off for Democracy Day	Public Holiday
// 20 Jun	Sunday	Father's Day	Observance
// 21 Jun	Monday	June Solstice	Season
// 20 Jul	Tuesday	Id el Kabir	Public Holiday
// 21 Jul	Wednesday	Id el Kabir additional holiday	Public Holiday
// 9 Aug	Monday	Al-Hijra observed	Local holiday	Jigawa, Kano, Katsina , Kebbi, Osun, Yobe
// 10 Aug	Tuesday	Al-Hijra observed	Local holiday	Oyo
// 20 Aug	Friday	Isese Day	Local holiday	Osun
// 27 Aug	Friday	State Creation Anniversary Day	Local holiday	Jigawa
// 22 Sep	Wednesday	September Equinox	Season
// 1 Oct	Friday	National Day	Public Holiday
// 19 Oct	Tuesday	Id el Maulud	Public Holiday
// 21 Dec	Tuesday	December Solstice	Season
// 22 Dec	Wednesday	Sambisa Memorial Day	Local holiday	Borno
// 24 Dec	Friday	Christmas Eve	Observance, Christian
// 25 Dec	Saturday	Christmas Day	Public Holiday
// 26 Dec	Sunday	Boxing Day	Public Holiday
// 31 Dec	Friday	New Year's Eve	Observance
//     }
// ]
