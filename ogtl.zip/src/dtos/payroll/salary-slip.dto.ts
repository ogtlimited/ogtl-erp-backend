/* eslint-disable prettier/prettier */
/* eslint-disable @typescript-eslint/adjacent-overload-signatures */

import {IsString, IsDate, IsNumber, IsArray, IsEnum } from 'class-validator';

export class CreateSalarySlipDto {

    @IsString()
    public action: string;

    // @IsString()
    // public employee: string;

    // @IsString()
    // public Branch: string;

    // @IsString()
    // public status: string;

    // @IsString()
    // public payrollEntry: string;

    // @IsString()
    // public letterHead: string;
    
    // @IsString()
    // public salaryStructure: string;
    
    // @IsString()
    // public salaryDeduction: string;
    
    // @IsString()
    // public payrollFrequency: string;
    
    // @IsString()
    // public bank: string;
    
    // @IsString()
    // public loans: string;

    // @IsString()
    // public totalInWords: string;

    // @IsNumber()
    // public totalWorkingDays: Number;
    
    // @IsNumber()
    // public paymentDays: Number;
    
    // @IsNumber()
    // public totalWorkingHours: Number;
    
    // @IsNumber()
    // public totalDeduction: Number;
    
    // @IsNumber()
    // public netPay: Number;

    // @IsDate()
    // public startDate: Date;

    // @IsDate()
    // public endDate: Date;

    // @IsArray()
    // deduction: Array<Object>
  
}

/*



*/