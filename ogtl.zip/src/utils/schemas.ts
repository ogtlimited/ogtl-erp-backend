const mongoose = require('mongoose');
export const modelNames = () => {
    return mongoose.modelNames();
}