/* eslint-disable prettier/prettier */
export interface IExpenseHeadDraft{
  departmentId?: String;
  projectId?: String;
  title?: String;
  flagAlert?: Number;
  createdBy?:String;
}
