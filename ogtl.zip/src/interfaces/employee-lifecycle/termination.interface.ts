/* eslint-disable prettier/prettier */

export interface ITermination {
    _id: string;
    employee: string;
    reason: string;
    terminationType : string
    terminationDate: Date;
  }
 