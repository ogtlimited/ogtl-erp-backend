/* eslint-disable prettier/prettier */
export interface ITransfer {
    employeeId: string;
    status: string;
    branch: string;  
    department: string;
    transferDetails: string;
    transferDate: Date;
  }
  