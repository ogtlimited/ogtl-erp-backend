/* eslint-disable prettier/prettier */
export interface IPromotion {
   _id: string;
    employee: string;
    newDesignation: string;
    promotionDate: Date;
  }
  