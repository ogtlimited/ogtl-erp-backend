/* eslint-disable prettier/prettier */
export interface Asset{
    assetId : string;
    assetName: string;
    serialNumber : string;
    assetType : string;

}