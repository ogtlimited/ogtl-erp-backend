/* eslint-disable prettier/prettier */
export interface assetAssignment{
    assetId : string;
    assigned_to: string;
    assigned_by : string;
    condition: string;
    warranty: string;
    description: string;
}