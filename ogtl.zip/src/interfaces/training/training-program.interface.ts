export interface ITrainingProgram {
    program_name:string;
    status: string;
    trainer_name: string;
    trainer_email: string;
    supplier_id: string;
    contact_number: string;
    description: string;
}
