export interface ITrainingAttendance {
    employee_id:string;
    training_event_id:string;
    feedback: string;
}