export interface ITrainingResult {
    training_event_id:string;
    training_result:string;
}
