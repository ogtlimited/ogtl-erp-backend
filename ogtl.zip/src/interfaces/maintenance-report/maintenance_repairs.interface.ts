/* eslint-disable prettier/prettier */

export interface IMaintenanceAndRepairs {
  asset_id: string;
  issue: string;
  date_of_maintenance: Date;
  amount: Number;
  status: string;
  type:string
}
