/* eslint-disable prettier/prettier */
export interface ILoanRepayment {
    amount_paid: string;
}