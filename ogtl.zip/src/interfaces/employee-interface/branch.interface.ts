/* eslint-disable prettier/prettier */
export interface Branch{
    _id: string;
    branch:string;
}