/* eslint-disable prettier/prettier */
export interface Education{
    _id: string;
    employee_id: string;
    school: string;
    qualification: string;
    level: string;
    year_of_passing: string;
}
