/* eslint-disable prettier/prettier */
export interface EmployeeType {
  _id: string;
  type: string;
}
