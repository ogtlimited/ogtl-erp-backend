/* eslint-disable prettier/prettier */
export interface Designation{
    _id: string;
    designation: string;
}