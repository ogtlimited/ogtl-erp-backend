/* eslint-disable prettier/prettier */
export interface ContactDetail {
    _id: string;
    employee_id: string;
    mobile: string;
    personal_email: string;
    parmanent_addresss_is: string;
    parmanent_addresss:string;
    current_address_is: string;
    current_address: string;
}
