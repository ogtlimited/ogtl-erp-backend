/* eslint-disable prettier/prettier */
export interface History{
    _id: string;
    employee_id: string;
    branch_id: string;
    designation_id: string;
    from_date: Date;
    to_date: Date;
}