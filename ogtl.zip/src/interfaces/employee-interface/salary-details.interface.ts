/* eslint-disable prettier/prettier */
export interface SalaryDetail{
    _id: string;
    employee_id: string;
    salary_mode: string;
    bank_name: string;
    bank_code: string;
    bank_account_number: string;
}
