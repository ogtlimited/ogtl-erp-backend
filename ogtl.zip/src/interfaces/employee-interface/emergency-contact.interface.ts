/* eslint-disable prettier/prettier */
export interface EmergencyContact{
    _id: string;
    employee_id: string;
    emergency_phone: string;
    emergency_contact_name:string;
    relation: string;

}
