/* eslint-disable prettier/prettier */
export interface Grade{
    _id: string;
    grade: string;
}