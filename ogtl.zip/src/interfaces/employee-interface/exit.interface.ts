/* eslint-disable prettier/prettier */
export interface Exit{
   _id: string;
   employee_id: string;
   resignation_letter_date: Date;
   relieving_date: Date;
   reason_for_resignation: string;
   
}