/* eslint-disable prettier/prettier */
export interface IDepartment{
    _id: string;
    department: string;
}