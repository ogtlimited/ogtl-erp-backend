/* eslint-disable prettier/prettier */
export interface WorkExperience {
  _id: string;
  employee_id: string;
  company: string;
  designation: string;
  salary: string;
  address: string;
}
