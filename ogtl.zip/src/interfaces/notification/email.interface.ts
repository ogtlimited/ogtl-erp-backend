/* eslint-disable prettier/prettier */
export interface IEmail {
    message: string;
    model_name: string;
    email_id: string;
    is_read: string;
    subject: string;
    sender: string;
}
