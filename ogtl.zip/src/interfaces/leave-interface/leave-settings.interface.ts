/* eslint-disable prettier/prettier */

export interface ILeaveSettings{
    _id: string;
    unused_leaves : number;
    carryover : number;

}