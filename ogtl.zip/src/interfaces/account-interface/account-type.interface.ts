/* eslint-disable prettier/prettier */
export interface IAccountType {
    name: string;
}