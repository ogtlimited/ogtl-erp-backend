/* eslint-disable prettier/prettier */
export interface ISalaryStructureAssignment {
    employeeIds?:Array<string>;
    salaryStructureId: String;
    fromDate: string
}
