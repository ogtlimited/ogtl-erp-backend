/* eslint-disable prettier/prettier */
export interface ICreateDeduction {
    deductionTypeId: string;
    employeeId: string;
  }
  