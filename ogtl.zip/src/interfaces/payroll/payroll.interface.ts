/* eslint-disable prettier/prettier */
export interface IPayRoll{
   departmentId: String;
   projectId: String;
}
