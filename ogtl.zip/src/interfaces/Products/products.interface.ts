/* eslint-disable prettier/prettier */
export interface IProductService {
    _id:string;
    product:string;
    description: string;
    rate:number;
    price: number;
    tax:number;
  }
