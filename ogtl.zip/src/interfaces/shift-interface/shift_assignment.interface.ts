export interface IShiftAssignment {
  _id: string;
  employee_id: string;
  shift_type_id: string;
  assignment_date: Date;
}
