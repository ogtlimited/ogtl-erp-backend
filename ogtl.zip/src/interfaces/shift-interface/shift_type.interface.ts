/* eslint-disable prettier/prettier */
export interface IShiftType {
  _id: string;
  shift_name: string;
  start_time: string;
  end_time: string;
  expectedWorkTime: string;
}
