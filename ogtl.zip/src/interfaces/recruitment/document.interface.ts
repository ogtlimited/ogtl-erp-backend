/* eslint-disable prettier/prettier */
export interface IDocument {
    file_path:string;
    file_size:string;
    job_id: string;
    file_type: string;
    file_name: string;
}