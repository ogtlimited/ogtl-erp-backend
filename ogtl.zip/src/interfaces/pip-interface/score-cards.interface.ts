export interface IScoreCard{
    _id: string;
    employee_id: string;
    performance_score : string;
    company_values_score:string;
    Department_id : string;
}