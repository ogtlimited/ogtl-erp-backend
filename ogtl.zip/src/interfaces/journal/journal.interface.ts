/* eslint-disable prettier/prettier */
export interface IJournal {
    account: string;
    ref: string;
    date: string;
    description: string;
    debit: number;
    credit: number;
  }