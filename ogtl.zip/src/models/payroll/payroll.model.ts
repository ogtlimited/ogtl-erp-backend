/* eslint-disable prettier/prettier */
import { IPayRoll } from '@/interfaces/payroll/payroll.interface';
import { model, Schema, Document } from 'mongoose';

/*
 Reconsider having an array field: employees

*/
const payRollSchema: Schema = new Schema(
  {
   
    departmentId: {
      type: Schema.Types.ObjectId,
      ref: "Department"
    },
    projectId: {
      type: Schema.Types.ObjectId,
      ref: "Project"
    },
    status: {
      type: Schema.Types.ObjectId,
      ref: "Status"
    },
    salarySlips:[
       {
        type: Schema.Types.ObjectId,
        required: true,
        ref: "SalarySlip"
      }
    ],
    startDate: {
      type: Date,
    },
    endDate: {
      type: Date,
    },
    totalAmount: {
      type: Number,
    },
    approved: {
      type: Boolean,
      default:false
    }
  },
  {
    timestamps: true,
  },
);

const payRollModel = model<IPayRoll & Document>('PayRoll', payRollSchema);
export default payRollModel;